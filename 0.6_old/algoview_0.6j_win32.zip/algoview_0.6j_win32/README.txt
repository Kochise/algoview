ALGOrithm VIEWer

Hello!

This is a small program that shows the diagram  of C source that is simiar to flowchart.
This program may help you analyze algorithm.
Algoview  supports C.
And it supports partially C++ and Intel assembly and AT&T assembly for X86 machine(*.asm *.s).

-----Warning------
 If you want to exit the program,
 You should not exit by pressing upper right "x" button 
in MS WINDOWS or X Window system,
 instead of it you should press ESC key or select Menu->exit.
------------------

Usage:
	Mouse Left Button	:Navigate the diagram
	Mouse Right Button	:Menu
	Mouse Wheel		:Move up/down 
	Shift + Mouse Wheel	:Move left/right 
	Arrow key		:Move finely
	Shift + Arrow key	:Move a half page
	PGUP			:Move up a half page
	PGDN			:Move down a half page
	
LICENSE:BSD
AUTHOR:JD Rhee
