char a="\
</test>\
";
main()A;B;C;{

	a;
	b;
	c;
	d;
}
main(){

	a;
	b;
	c;
	d;
}

main(){

	a;
	b;
	c;
	d;
}



main(){

	a;
	b;
	c;
	d;
}
