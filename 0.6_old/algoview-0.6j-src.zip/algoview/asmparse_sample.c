
int	find_label_by_string_array_index(label_array *a,int n,int index){
	int	i;
	label	*lp;
	
	while(i<n){
		if(index==lp->si){
			break ;
		}
		//lp=get_label_array(a,i,64);
	}
	return	0;
}

