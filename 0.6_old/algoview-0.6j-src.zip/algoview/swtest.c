int main(){
	int i;
	typedef struct a{
		int a:1,b:2;
		int c;

	}b;
	struct{
		int k;
	}c;
	
	for(i=0;i<100;i++)
	{
		i+=2;
		if(i)continue;
		}

	switch(i){
		case	1:
	switch(j){
		case	1:
	switch(j){
		case	1:
			j=2;
			break;
		case	2:
			j=3;
		case	3:
			j=4;
			break;
		case	4:
			j=1;
			break;
		default:
	}
			j=2;
			break;
		case	2:
			j=3;
		case	3:
			j=4;
			break;
		case	4:
			j=1;
			break;
	}
		goto L1;

			i=2;
			break;
		case	2:
			i=3;
		case	3:
			i=4;
			break;
		case	4:
			i=1;
			break;
	}
	
	L0:
	L1:

		while(1)		goto L0;
		if(1);
		else i; 
		aaa();

	return 1;
}
