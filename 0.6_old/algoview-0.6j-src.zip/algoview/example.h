/* Allegro datafile object indexes, produced by grabber v4.1.4 (WIP), Unix */
/* Datafile: /root/algoview_test/font.dat */
/* Date: Tue Jul 29 18:09:12 2003 */
/* Do not hand edit! */

#define                                  0        /* FONT */

