/* font_dat.h
 * 
 *  Converted datafile header for font.dat .
 *  See font_dat.c for definitions.
 *  Do not hand edit.
 */

#ifndef ALLEGRO_H
#error You must include allegro.h
#endif

#ifndef FONT_DAT_H
#define FONT_DAT_H

#ifdef __cplusplus
extern "C" {
#endif



extern DATAFILE data[];

#define FONT_0 0
#define COUNT 1



#ifdef __cplusplus
}
#endif

#endif /* include guard */

/* end of font_dat.h */



